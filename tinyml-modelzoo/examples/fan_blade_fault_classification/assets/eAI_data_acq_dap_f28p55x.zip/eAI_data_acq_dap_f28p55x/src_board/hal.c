//###########################################################################
// $Copyright:
// Copyright (C) 2017-2024 Texas Instruments Incorporated - http://www.ti.com/
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//   Redistributions of source code must retain the above copyright
//   notice, this list of conditions and the following disclaimer.
//
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the
//   documentation and/or other materials provided with the
//   distribution.
//
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//###########################################################################


//! \file   \solutions\edge_diagnosis_EVM\f28p55x\hal.c
//! \brief  Contains the various functions related to the HAL object
//!
//
#include <src_device/device.h>
#include <src_device/driverlib.h>
#include "hal.h"
#include "adxl355.h"

void HAL_setupGPIOs(void){
        //
        // Toggle LED for reference
        // GPIO12 is LED4
        // GPIO13 is LED5
        //
        GPIO_setPadConfig(DEVICE_GPIO_PIN_LED1, GPIO_PIN_TYPE_STD);
        GPIO_setDirectionMode(DEVICE_GPIO_PIN_LED1, GPIO_DIR_MODE_OUT);

        GPIO_setPadConfig(DEVICE_GPIO_PIN_LED2, GPIO_PIN_TYPE_STD);
        GPIO_setDirectionMode(DEVICE_GPIO_PIN_LED2, GPIO_DIR_MODE_OUT);

        GPIO_writePin(DEVICE_GPIO_PIN_LED1, 1);
        GPIO_writePin(DEVICE_GPIO_PIN_LED2, 0);

        // GPIO count vibration XINT frequency
        GPIO_setPinConfig(GPIO_24_GPIO24);
        GPIO_setDirectionMode(24, GPIO_DIR_MODE_OUT);
        GPIO_setPadConfig(24, GPIO_PIN_TYPE_STD);
        GPIO_writePin(24, 0);

        // GPIO count SPI motor data frequency
        GPIO_setPinConfig(GPIO_51_GPIO51);
        GPIO_setDirectionMode(51, GPIO_DIR_MODE_OUT);
        GPIO_setPadConfig(51, GPIO_PIN_TYPE_STD);
        GPIO_writePin(51, 0);

        // GPIO count 20kHz timestamp frequency
        GPIO_setPinConfig(GPIO_5_GPIO5);
        GPIO_setDirectionMode(5, GPIO_DIR_MODE_OUT);
        GPIO_setPadConfig(5, GPIO_PIN_TYPE_STD);
        GPIO_writePin(5, 0);

        GPIO_setPinConfig(GPIO_6_GPIO6);
        GPIO_setDirectionMode(6, GPIO_DIR_MODE_OUT);
        GPIO_setPadConfig(6, GPIO_PIN_TYPE_STD);
        GPIO_writePin(6, 0);

        GPIO_setPinConfig(GPIO_7_GPIO7);
        GPIO_setDirectionMode(7, GPIO_DIR_MODE_OUT);
        GPIO_setPadConfig(7, GPIO_PIN_TYPE_STD);
        GPIO_writePin(7, 0);

        GPIO_setPinConfig(GPIO_10_GPIO10);
        GPIO_setDirectionMode(10, GPIO_DIR_MODE_OUT);
        GPIO_setPadConfig(10, GPIO_PIN_TYPE_STD);
        GPIO_writePin(10, 0);

        GPIO_setPinConfig(GPIO_11_GPIO11);
        GPIO_setDirectionMode(11, GPIO_DIR_MODE_OUT);
        GPIO_setPadConfig(11, GPIO_PIN_TYPE_STD);
        GPIO_writePin(11, 0);



        // Configure GPIO for vibration sensor
        // CS -> GPIO27
        GPIO_setPinConfig(GPIO_27_GPIO27);
        GPIO_setDirectionMode(27, GPIO_DIR_MODE_OUT);
        GPIO_setPadConfig(27, GPIO_PIN_TYPE_STD);
        SPI_CS_HIGH;

        // Clock -> GPIO14
        GPIO_setPinConfig(GPIO_14_SPIB_CLK);
        GPIO_setDirectionMode(14, GPIO_DIR_MODE_OUT);
        GPIO_setPadConfig(14, GPIO_PIN_TYPE_STD);

        // PICO -> GPIO60
        GPIO_setPinConfig(GPIO_60_SPIB_PICO);
        GPIO_setDirectionMode(60, GPIO_DIR_MODE_OUT);
        GPIO_setPadConfig(60, GPIO_PIN_TYPE_STD);

        // POCI -> GPIO61
        GPIO_setPinConfig(GPIO_61_SPIB_POCI);
        GPIO_setDirectionMode(61, GPIO_DIR_MODE_IN);
        GPIO_setPadConfig(61, GPIO_PIN_TYPE_STD);

        // DATA_RDY -> GPIO16
        GPIO_setPinConfig(GPIO_16_GPIO16);
        GPIO_setDirectionMode(16, GPIO_DIR_MODE_IN);
        GPIO_setPadConfig(16, GPIO_PIN_TYPE_STD);
        GPIO_setQualificationMode(16, GPIO_QUAL_SYNC);

        GPIO_setInterruptType(GPIO_INT_XINT3, GPIO_INT_TYPE_RISING_EDGE);
        GPIO_setInterruptPin(16, GPIO_INT_XINT3);
        GPIO_enableInterrupt(GPIO_INT_XINT3);

        // Configure GPIO for SPI communication with motor controller
        // PTE -> GPIO57
        GPIO_setPinConfig(GPIO_57_SPIA_PTE);
        GPIO_setDirectionMode(57, GPIO_DIR_MODE_IN);
        GPIO_setPadConfig(57, GPIO_PIN_TYPE_STD);

        // Clock -> GPIO9
        GPIO_setPinConfig(GPIO_9_SPIA_CLK);
        GPIO_setDirectionMode(9, GPIO_DIR_MODE_IN);
        GPIO_setPadConfig(9, GPIO_PIN_TYPE_STD);

        // PICO -> GPIO8
        GPIO_setPinConfig(GPIO_8_SPIA_PICO);
        GPIO_setDirectionMode(8, GPIO_DIR_MODE_IN);
        GPIO_setPadConfig(8, GPIO_PIN_TYPE_STD);

        // POCI -> GPIO17
        GPIO_setPinConfig(GPIO_17_SPIA_POCI);
        GPIO_setDirectionMode(17, GPIO_DIR_MODE_OUT);
        GPIO_setPadConfig(17, GPIO_PIN_TYPE_STD);


        // Configure GPIO for SCI
        // SCIA RX -> GPIO28
        GPIO_setPinConfig(GPIO_28_SCIA_RX);
        GPIO_setDirectionMode(28, GPIO_DIR_MODE_IN);
        GPIO_setPadConfig(28, GPIO_PIN_TYPE_STD);

        // SCIA TX -> GPIO29
        GPIO_setPinConfig(GPIO_29_SCIA_TX);
        GPIO_setDirectionMode(29, GPIO_DIR_MODE_OUT);
        GPIO_setPadConfig(29, GPIO_PIN_TYPE_STD);

}

void HAL_setupPWM(void)
{
    // SCI TX Timer
    EPWM_setPeriodLoadMode(EPWM1_BASE, EPWM_PERIOD_DIRECT_LOAD);
    EPWM_setTimeBasePeriod(EPWM1_BASE, TX_TIME_BASE_TBPRD);
    EPWM_setPhaseShift(EPWM1_BASE, 0);
    EPWM_setTimeBaseCounter(EPWM1_BASE, 0);
    EPWM_setTimeBaseCounterMode(EPWM1_BASE, EPWM_COUNTER_MODE_UP);    // increment counting
    EPWM_setClockPrescaler(EPWM1_BASE, EPWM_CLOCK_DIVIDER_1,
                           EPWM_HSCLOCK_DIVIDER_8);

    // EPWM1 INT to generate SCI TX
    EPWM_setInterruptSource(EPWM1_BASE, EPWM_INT_TBCTR_PERIOD);
    EPWM_setInterruptEventCount(EPWM1_BASE, 1);

    // Enable Interrupt Generation from the PWM module
    EPWM_enableInterrupt(EPWM1_BASE);

    // Clear ePWM Interrupt flag
    EPWM_clearEventTriggerInterruptFlag(EPWM1_BASE);

#if defined(TEST_COMM)
    // Vibration sensor timer
    EPWM_setPeriodLoadMode(EPWM2_BASE, EPWM_PERIOD_DIRECT_LOAD);
    EPWM_setTimeBasePeriod(EPWM2_BASE, VIB_TIME_BASE_TBPRD);
    EPWM_setPhaseShift(EPWM2_BASE, 0);
    EPWM_setTimeBaseCounter(EPWM2_BASE, 0);
    EPWM_setTimeBaseCounterMode(EPWM2_BASE, EPWM_COUNTER_MODE_UP);    // increment counting
    EPWM_setClockPrescaler(EPWM2_BASE, EPWM_CLOCK_DIVIDER_1,
                           EPWM_HSCLOCK_DIVIDER_8);

    // EPWM2 INT to generate VIB Read
    EPWM_setInterruptSource(EPWM2_BASE, EPWM_INT_TBCTR_PERIOD);
    EPWM_setInterruptEventCount(EPWM2_BASE, 1);

    // Enable Interrupt Generation from the PWM module
    EPWM_enableInterrupt(EPWM2_BASE);

    // Clear ePWM Interrupt flag
    EPWM_clearEventTriggerInterruptFlag(EPWM2_BASE);


// Test vibration data only
      // Motor timer
//        EPWM_setPeriodLoadMode(EPWM3_BASE, EPWM_PERIOD_DIRECT_LOAD);
//        EPWM_setTimeBasePeriod(EPWM3_BASE, MTR_TIME_BASE_TBPRD);
//        EPWM_setPhaseShift(EPWM3_BASE, 0);
//        EPWM_setTimeBaseCounter(EPWM3_BASE, 0);
//        EPWM_setTimeBaseCounterMode(EPWM3_BASE, EPWM_COUNTER_MODE_UP);    // increment counting
//        EPWM_setClockPrescaler(EPWM3_BASE, EPWM_CLOCK_DIVIDER_1,
//                               EPWM_HSCLOCK_DIVIDER_8);
//
//        // EPWM1 INT to generate Motor Read
//        EPWM_setInterruptSource(EPWM3_BASE, EPWM_INT_TBCTR_PERIOD);
//        EPWM_setInterruptEventCount(EPWM3_BASE, 1);
//
//        // Enable Interrupt Generation from the PWM module
//        EPWM_enableInterrupt(EPWM3_BASE);
//
//        // Clear ePWM Interrupt flag
//        EPWM_clearEventTriggerInterruptFlag(EPWM3_BASE);
# endif // TEST_COMM

}


// end of file
