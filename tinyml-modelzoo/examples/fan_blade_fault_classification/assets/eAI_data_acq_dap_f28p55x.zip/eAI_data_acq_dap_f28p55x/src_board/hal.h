//###########################################################################
// $Copyright:
// Copyright (C) 2017-2024 Texas Instruments Incorporated - http://www.ti.com/
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//   Redistributions of source code must retain the above copyright
//   notice, this list of conditions and the following disclaimer.
//
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the
//   documentation and/or other materials provided with the
//   distribution.
//
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//###########################################################################


//! \file   \solutions\edge_diagnosis_EVM\f28p55x\hal.h
//! \brief  
//!         
//!


#ifndef HAL_H
#define HAL_H


//*****************************************************************************
//
// If building with a C++ compiler, make all of the definitions in this header
// have a C binding.
//
//*****************************************************************************
#ifdef __cplusplus
extern "C"
{
#endif

//*****************************************************************************
//
//! \defgroup HAL HAL
//! @{
//
//*****************************************************************************



// platforms


// the defines
// Comment for using DA protocol
//
//#if defined(F28P65X_AI_EVM) || defined(F28P55X_AI_EVM)
//
////#define SCI_BAUD_RATE       19201
////#define SCI_BAUD_RATE       38402
////#define SCI_BAUD_RATE       57603
////#define SCI_BAUD_RATE      115207
////#define SCI_BAUD_RATE      260416
////#define SCI_BAUD_RATE      384615
////#define SCI_BAUD_RATE      581395
////#define SCI_BAUD_RATE      757575
////#define SCI_BAUD_RATE      892857
////#define SCI_BAUD_RATE     1000000
////#define SCI_BAUD_RATE     1190476
////#define SCI_BAUD_RATE     1250000
////#define SCI_BAUD_RATE     1562500
////#define SCI_BAUD_RATE     1666660
////#define SCI_BAUD_RATE     1785700
////#define SCI_BAUD_RATE     1923075
////#define SCI_BAUD_RATE     2083330
////#define SCI_BAUD_RATE     2272720
//#if defined(F28P65X_AI_EVM)
//#define SCI_BAUD_RATE     2500000
//#endif
////#define SCI_BAUD_RATE     2777777
//#if defined(F28P55X_AI_EVM)
//#define SCI_BAUD_RATE       3125000
//#endif
//#endif  // F28P65X_AI_EVM


#define USER_SYSTEM_FREQ_Hz             (float32_t)(DEVICE_SYSCLK_FREQ)
#define USER_SYSTEM_FREQ_MHz            (float32_t)(USER_SYSTEM_FREQ_Hz / 1000000.0f)
#define USER_PWM_CLOCK_MHz              (float32_t)(USER_SYSTEM_FREQ_MHz / 4.0f)


#define SCITX_DATA_kHz                  (float32_t)(15.0f)             // 15.0f original
#define TX_TIME_BASE_TBPRD              (uint16_t)((USER_PWM_CLOCK_MHz / 2.0f * 1000.0f / SCITX_DATA_kHz) - 1.0f)


#define VIB_DATA_RD_kHz                 (float32_t)(4.0f)           // 4.0f 4kHz
#define VIB_TIME_BASE_TBPRD             (uint16_t)((USER_PWM_CLOCK_MHz / 2.0f * 1000.0f / VIB_DATA_RD_kHz) - 1.0f)

#define MTR_DATA_RD_kHz                 (float32_t)(6.0f)           // 5.0f  5kHz
#define MTR_TIME_BASE_TBPRD             (uint16_t)((USER_PWM_CLOCK_MHz / 2.0f * 1000.0f / MTR_DATA_RD_kHz) - 1.0f)




//! \brief     Sets up PWM to generate clock/index
//!
extern void HAL_setupPWM(void);


//! \brief     Sets up the GPIO (General Purpose I/O) pins
//!
extern void HAL_setupGPIOs(void);













//*****************************************************************************
//
// Close the Doxygen group.
//! @}
//
//*****************************************************************************

//*****************************************************************************
//
// Mark the end of the C bindings section for C++ compilers.
//
//*****************************************************************************
#ifdef __cplusplus
}
#endif

#endif // end of HAL_H definition

