//###########################################################################
// $Copyright:
// Copyright (C) 2017-2024 Texas Instruments Incorporated - http://www.ti.com/
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//   Redistributions of source code must retain the above copyright
//   notice, this list of conditions and the following disclaimer.
//
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the
//   documentation and/or other materials provided with the
//   distribution.
//
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//###########################################################################
//
// FILE:   data_acq_main.c
//
//
// TITLE:  F28P55X LaunchPad data acquisition for Edge-AI diagnosis
//
//

//
// Included Files
//
#include <src_device/device.h>
#include <src_device/driverlib.h>
#include "adxl355.h"
#include "mtr_data.h"
#include "hal.h"
#include <string.h>

#include "dap_interface.h"
#include "dap_core.h"
//
// Defines
//

// Consider only vibration data for now
#define VIB_DATA_LEN        12
#define SEQ_HEADER_LEN      2
//#define MTR_DATA_LEN    10
#define TRX_DATA_LEN        (VIB_DATA_LEN+SEQ_HEADER_LEN)



#define RTX_IDLE        0    // Idle, wait receive/transmit
#define RTX_GOING       1    // In receive/transmit process
#define RTX_SUCCESS     2    // receive/transmit
#define RTX_FAILED      3    // receive/transmit Failed

#define TRX_WAIT_TIME_SET   500

#define GPIO_SCITX_TIMER    6
#define GPIO_TVIB_TIMER     7
#define GPIO_TMTR_TIMER     10
#define GPIO_SVIB_TIMER     11
#define GPIO_SMTR_TIMER     5


#define GPIO_LED_RED        12

#define LED_GREEN_FREQ_NUM  2           // 0.5k
#define LED_RED_FREQ_NUM    2000       // 10.0k

//
// Globals

#pragma CODE_SECTION(spiRxFIFOISR, ".TI.ramfunc");
__interrupt void spiRxFIFOISR(void);

#pragma CODE_SECTION(vibDataISR, ".TI.ramfunc");
__interrupt void vibDataISR(void);

#pragma CODE_SECTION(sciTxTimerISR, ".TI.ramfunc");
__interrupt void sciTxTimerISR(void);

#if defined(TEST_COMM)
#pragma CODE_SECTION(vibTimerISR, ".TI.ramfunc");
__interrupt void vibTimerISR(void);
#endif // TEST_COMM

#if defined(TEST_COMM)
uint32_t vibTimerISRCount = 0;
uint32_t timestampVib = 0;
#endif  // TEST_SER

extern volatile int start_sending_data;

ADXL355_Handle adxl355Handle;
ADXL355_Obj    adxl355;

uint16_t DeviceID, DeviceMST, RevID, DeviceAD, Range_back, status;

float X_data_float, Y_data_float, Z_data_float;

uint16_t BGloopcount = 0;
uint16_t vibDataRDY = 0;
uint16_t mtrDataRDY = 0;

uint16_t i=0;
uint16_t startTxCmd = 0;
uint16_t completedTxCmd = 0;
uint16_t startTxVibCmd = 0;
uint16_t startTxMtrCmd = 0;
uint16_t TxDataReady = 0;
uint16_t EnableTRx = 0;
uint16_t TxStatus = RTX_IDLE;
uint16_t RxStatus = RTX_IDLE;

uint16_t TRxWaitTimeCnt = 0;
uint16_t TRxWaitTimeSet = TRX_WAIT_TIME_SET;

uint16_t RxWaitTimeCnt = 0;
uint16_t TxWaitTimeCnt = 0;
uint16_t RxWaitTimeSet = TRX_WAIT_TIME_SET;
uint16_t TxWaitTimeSet = TRX_WAIT_TIME_SET;

uint16_t RxFailedTimesCnt = 0;
uint16_t TxFailedTimesCnt = 0;

uint16_t RxCommand = 0;
uint16_t TxCommand = 0;

uint16_t RxDataValue = 0;
int16_t  TxDataValue = 0;

uint16_t RxDataChkSum = 0;

uint16_t aiTxDataBuf[TRX_DATA_LEN];      // transmitting data
//uint16_t aiRxDataBuf[TRX_DATA_LEN];      // Receiving data

//uint16_t vibCheckSum;
//uint16_t mtrCheckSum;

uint16_t rx_mtr_data[MTR_DATA_NUM+1];

/* Motor data buffer */
#define MTR_BUFF_SAMPLES     1250
#define MTR_BUFF_LEN         MTR_BUFF_SAMPLES

/* Motor data structure definition */
typedef struct _SER_data_t_
{
    uint16_t timestamp;
    uint16_t ctrlStatus;
    uint16_t vol_DC;
    uint16_t speed_Hz;
    uint16_t cur_U;
    uint16_t cur_V;
    uint16_t cur_W;
}SER_data_t;

SER_data_t mtrSampleData;
SER_data_t mtrDataBuff[MTR_BUFF_LEN];       // motor data buffer, container of <SER_data_t>

SER_data_t *ptr_data_in;                    // pointer to write buffer
SER_data_t *ptr_data_out;                   // pointer to read buffer

#pragma DATA_SECTION(mtrDataBuff, "ramgs2");

/* Vibration data buffer */
#define VIB_BUFF_SAMPLES      750
#define VIB_BUFF_LEN          VIB_BUFF_SAMPLES

/* Vibration data structure definition */
typedef struct _VIB_data_t_{
    uint16_t seq_header;
    int32_t vib_X;
    int32_t vib_Y;
    int32_t vib_Z;
}VIB_data_t;

VIB_data_t vibSampleData;
VIB_data_t vibDataBuff[VIB_BUFF_LEN];

#pragma DATA_SECTION(vibDataBuff, "ramgs1");


int16_t mtrIndexWrite = 0;
int16_t vibIndexWrite = 0;
int16_t mtrIndexSciTx = 0;
int16_t vibIndexSciTx = 0;

int16_t vibTxDelta = 0;
int16_t mtrTxDelta = 0;
int16_t vibTxMissedCount = 0;
int16_t mtrTxMissedCount = 0;

int32_t TimerIsrCount = 0;
int32_t VibSPIIsrCount = 0;
int32_t mtrSPIIsrCount = 0;

int32_t scidataTxCount = 0;
int32_t vibdataTxCount = 0;
int32_t mtrdataTxCount = 0;

int32_t mtrSciTxNum = 0;
int32_t vibSciTxNum = 0;

uint32_t vibdataRequiredNum = 1024;        // fixed at 1024 for current test case
uint32_t mtrdataRequiredNum = 0;

uint32_t periodLEDGreenCount = 0;
uint32_t periodLEDGreenSet   = LED_GREEN_FREQ_NUM;      // 1k
uint32_t periodLEDRedCount   = 0;
uint32_t periodLEDRedSet     = LED_RED_FREQ_NUM;        // 12.5k

// Sequence header for DA protocol
typedef struct seq_header{
  uint16_t sensor_ID: 3;
  uint16_t index: 13;
} seq_header_t;

seq_header_t vib_sequence;

#define SEQ_IND_BITS    13
#define SEQ_IND_MAX     (1<<13)

//
// Main
//
void main(void)
{
    // data buffer initialization
    memset(mtrDataBuff, 0, MTR_BUFF_LEN * sizeof(SER_data_t));
    memset(vibDataBuff, 0, VIB_BUFF_LEN * sizeof(VIB_data_t));

    //
    // Initialize device clock and peripherals
    //
    Device_init();

    //
    // Disable pin locks and enable internal pull-ups.
    //
    Device_initGPIO();


    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();

    //

    HAL_setupGPIOs();
    HAL_setupPWM();

    Interrupt_initModule();
    Interrupt_initVectorTable();

    Interrupt_register(INT_EPWM1, &sciTxTimerISR);
    Interrupt_enable(INT_EPWM1);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP3);

#if defined(TEST_COMM)
    Interrupt_register(INT_EPWM2, &vibTimerISR);
    Interrupt_enable(INT_EPWM2);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP3);
#endif  // TEST_COMM

    Interrupt_register(INT_SPIA_RX, &spiRxFIFOISR);
    MTR_DATA_setupSPI_PERI();
    Interrupt_enable(INT_SPIA_RX);

    Interrupt_register(INT_XINT3, &vibDataISR);
    Interrupt_enable(INT_XINT3);

    // Initiate ADXL355 object and configure SPI
    adxl355Handle = ADXL355_init(&adxl355);
    ADXL355_setupSPI(adxl355Handle);

    // Read device ID
    DeviceID = ADXL355_readRegister(adxl355Handle, ADXL355_PARTID, READ_1_BYTE);
    RevID = ADXL355_readRegister(adxl355Handle, ADXL355_REVID, READ_1_BYTE);
    DeviceMST = ADXL355_readRegister(adxl355Handle, ADXL355_DEVID_MST, READ_1_BYTE);
    DeviceAD = ADXL355_readRegister(adxl355Handle, ADXL355_DEVID_AD, READ_1_BYTE);

    // Setup range, ODR and filter
    ADXL355_setupRange(adxl355Handle);

    // If no problem in reading ID and configuration, start the sensor measurement
    ADXL355_Startup(adxl355Handle);

    // Test read temperature
    status = ADXL355_readRegister(adxl355Handle, ADXL355_POWER_CTL, READ_1_BYTE);
    Range_back = ADXL355_readRegister(adxl355Handle, ADXL355_RANGE, READ_1_BYTE);

    //
    // Different as sensor index, should follow the order from configure pipeline command and start from 1
    vib_sequence.sensor_ID = 1;

    // SCI setup for DAP testing
    SCI_init();

#if defined(TEST_COMM)

    vibSampleData.vib_X = 0x050607;    // lower 4-bit has no meaning
    vibSampleData.vib_Y = 0x08090A;
    vibSampleData.vib_Z = 0x0B0C0D;

#endif  // TEST_COMM

    startTxMtrCmd = 1;


    //
    // Enable Global Interrupt (INTM) and real time interrupt (DBGM)
    //
    EINT;
    ERTM;

    while(1)
    {
        BGloopcount++;
    }
}

uint32_t vib_Xu;
uint32_t vib_Yu;
uint32_t vib_Zu;

// Task 1 <Lowest>: RTM
// 4kHz
__interrupt void vibDataISR(void)
{
    GPIO_writePin(GPIO_SVIB_TIMER, 1);

    // Test interrupt
    vib_Xu = ADXL355_readRegister(adxl355Handle, ADXL355_XDATA3, READ_3_BYTE) >> 4;

    if((vib_Xu & 0x00080000) != 0)
    {
        vibSampleData.vib_X = vib_Xu | 0xFFF00000;
    }
    else
    {
        vibSampleData.vib_X = vib_Xu;
    }

    vib_Yu = ADXL355_readRegister(adxl355Handle, ADXL355_YDATA3, READ_3_BYTE) >> 4;

    if((vib_Yu & 0x00080000) != 0)
    {
        vibSampleData.vib_Y = vib_Yu | 0xFFF00000;
    }
    else
    {
        vibSampleData.vib_Y = vib_Yu;
    }

    vib_Zu = ADXL355_readRegister(adxl355Handle, ADXL355_ZDATA3, READ_3_BYTE) >> 4;

    if((vib_Zu & 0x00080000) != 0)
    {
        vibSampleData.vib_Z = vib_Zu | 0xFFF00000;
    }
    else
    {
        vibSampleData.vib_Z = vib_Zu;
    }

    if(start_sending_data != 0)
    {
        vibDataRDY = 1;

        vib_sequence.index++;
        if(vib_sequence.index == SEQ_IND_MAX){
            vib_sequence.index = 0;
        }

        vibSampleData.seq_header = (vib_sequence.sensor_ID << SEQ_IND_BITS) | vib_sequence.index;

        vibDataBuff[vibIndexWrite] = vibSampleData;

        vibIndexWrite++;

        if(vibIndexWrite >= VIB_BUFF_LEN)
        {
            vibIndexWrite = 0;
        }
    }

    VibSPIIsrCount++;

    GPIO_writePin(GPIO_SVIB_TIMER, 0);

    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP12);
}


// Task 2 <Medium>: Not scope for RTM
// 6kHz
__interrupt void spiRxFIFOISR(void)
{
    // Notify CPU that enough data has been received
    uint16_t j;

    GPIO_writePin(GPIO_SMTR_TIMER, 1);

#if defined(CMD_TO_MTR)
    SPI_resetTxFIFO(SPIA_BASE);
#endif

    for(j = 0; j < MTR_DATA_NUM; j++)
    {
        rx_mtr_data[j] = SPI_readDataNonBlocking(SPIA_BASE);

#if defined(CMD_TO_MTR)
        if(!set_cmd)
        {
            SPI_writeDataNonBlocking(SPIA_BASE, 0x0);
        }
#endif
    }

    mtrSampleData.vol_DC   = rx_mtr_data[3];
    mtrSampleData.speed_Hz = rx_mtr_data[4];
    mtrSampleData.cur_U    = rx_mtr_data[0];
    mtrSampleData.cur_V    = rx_mtr_data[1];
    mtrSampleData.cur_W    = rx_mtr_data[2];

    SPI_resetRxFIFO(SPIA_BASE);

    if(startTxCmd != 0)
    {
        mtrDataRDY = 1;

        mtrSampleData.timestamp++;

        mtrDataBuff[mtrIndexWrite] = mtrSampleData;

        mtrIndexWrite++;

        if(mtrIndexWrite >= MTR_BUFF_LEN)
        {
            mtrIndexWrite = 0;
        }
    }   // startTxCmd

#if defined(CMD_TO_MTR)
    if(set_cmd)
    {
        SPI_writeDataNonBlocking(SPIA_BASE, 0x4353);    // code for 'CS'
        SPI_writeDataNonBlocking(SPIA_BASE, mtr_op_cmd);
        SPI_writeDataNonBlocking(SPIA_BASE, cmd_freq_Hz);
        SPI_writeDataNonBlocking(SPIA_BASE, 0x0);
        SPI_writeDataNonBlocking(SPIA_BASE, 0x0);
        set_cmd = 0;

        // only move to next state if the motor is commanded to be running
        if(mtr_op_cmd)
        {
            new_cmd = 1;
            thresReachCnt = 0;
        }
    }   // set_cmd

    if(new_cmd)
    {
        speed_err = (int16_t)(rx_mtr_data[4]) - (int16_t)(cmd_freq_Hz);

        if(speed_err <= ERR_THRES && speed_err >= -ERR_THRES)
        {
            thresReachCnt++;
        }
        else thresReachCnt = 0;

        if(thresReachCnt == NUM_HIT_THRES)
        {
            mtr_stable = 1;
            new_cmd = 0;            // motor speed is stable under this test condition
            thresReachCnt = 0;
        }
    }   // new_cmd
#endif

    mtrSPIIsrCount++;

    GPIO_writePin(GPIO_SMTR_TIMER, 0);

    SPI_clearInterruptStatus(SPIA_BASE, SPI_INT_RXFF);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP6);
}



// Task 3 <High>:
__interrupt void sciTxTimerISR(void)
{
     GPIO_writePin(GPIO_SCITX_TIMER, 1);

    /* Main code part for data streaming */
    /************************************************
     * No CRC for now
     * No required number of samples from host for now
     * Move RX command to SCI RX ISR for immediate response
     *
     **************************************************/

     if(start_sending_data != 0)
     {
//         if((vibDataRDY == 1) && (TxDataReady == 0) && (vibdataTxCount < vibdataRequiredNum))   //
         if((vibDataRDY == 1) && (TxDataReady == 0) && (vibdataTxCount < vibdataRequiredNum))
         {
             //
             aiTxDataBuf[0] = (vibDataBuff[vibIndexSciTx].seq_header >> 8) & 0xFF;
             aiTxDataBuf[1] = vibDataBuff[vibIndexSciTx].seq_header & 0xFF;

             // each axis has to be 32-bit to stay uniform with the data type defined in DAP
             aiTxDataBuf[2] = (vibDataBuff[vibIndexSciTx].vib_X >> 24) & 0xFF;
             aiTxDataBuf[3] = (vibDataBuff[vibIndexSciTx].vib_X >> 16) & 0xFF;
             aiTxDataBuf[4] = (vibDataBuff[vibIndexSciTx].vib_X >> 8) & 0xFF;
             aiTxDataBuf[5] = (vibDataBuff[vibIndexSciTx].vib_X) & 0xFF;


             aiTxDataBuf[6] = (vibDataBuff[vibIndexSciTx].vib_Y >> 24) & 0xFF;
             aiTxDataBuf[7] = (vibDataBuff[vibIndexSciTx].vib_Y >> 16) & 0xFF;
             aiTxDataBuf[8] = (vibDataBuff[vibIndexSciTx].vib_Y >> 8) & 0xFF;
             aiTxDataBuf[9] = (vibDataBuff[vibIndexSciTx].vib_Y) & 0xFF;

             aiTxDataBuf[10] = (vibDataBuff[vibIndexSciTx].vib_Z >> 24) & 0xFF;
             aiTxDataBuf[11]  = (vibDataBuff[vibIndexSciTx].vib_Z >> 16) & 0xFF;
             aiTxDataBuf[12] = (vibDataBuff[vibIndexSciTx].vib_Z >> 8) & 0xFF;
             aiTxDataBuf[13] = (vibDataBuff[vibIndexSciTx].vib_Z) & 0xFF;


             vibIndexSciTx++;       // Index of vibration data buffer

             if(vibIndexSciTx >= VIB_BUFF_LEN)
             {
                 vibIndexSciTx = 0;
             }


             vibdataTxCount++;      // Total number of data samples count

             TxDataReady = 1;
             vibDataRDY = 0;

         }  // vibDataRDY


         TxWaitTimeCnt++;

         if(TxDataReady == 1)
         {
             if(SCI_getTxFIFOStatus(SCI_INST_BASE_ADDR) == SCI_FIFO_TX0)
             {

                 // sensor index pack to TxDataBuf
                 received_data_response(TRX_DATA_LEN, sensor_signal, &aiTxDataBuf[0]);

                 TxStatus = RTX_SUCCESS;
                 TxDataReady = 0;
                 TxWaitTimeCnt = 0;

                 scidataTxCount++;

                 periodLEDRedCount++;
                 if(periodLEDRedCount > periodLEDRedSet)
                 {
                     periodLEDRedCount = 0;
                     GPIO_togglePin(GPIO_LED_RED);
                 }
             }
             else if(TxWaitTimeCnt > TxWaitTimeSet)
             {
                 TxStatus = RTX_FAILED;
                 TxWaitTimeCnt = 0;

                 SCI_resetTxFIFO(SCI_INST_BASE_ADDR);
             }
         }

         vibSciTxNum = vibdataTxCount;
    }   // startTxCmd != 0)

     /* End of Main code part for data streaming */

     /* reset */
     if(start_sending_data == 0){
         vibDataRDY = 0;

         vibIndexWrite = 0;
         vibIndexSciTx = 0;

         vibdataTxCount = 0;

         // Index always start from 0
         vib_sequence.index = 0;
     }

     if(property_change_flag == 1){
         vibdataRequiredNum = property_val_uint32;
         property_change_flag = 0;
     }


    TimerIsrCount++;

    GPIO_writePin(GPIO_SCITX_TIMER, 0);

    EPWM_clearEventTriggerInterruptFlag(EPWM1_BASE);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP3);
}


#if defined(TEST_COMM)
__interrupt void vibTimerISR(void)
{
    GPIO_writePin(GPIO_TVIB_TIMER, 1);

    if((start_sending_data != 0) && (vibdataTxCount < vibdataRequiredNum))
    {
        vibDataRDY = 1;

        vib_sequence.index++;
        if(vib_sequence.index == SEQ_IND_MAX){
            vib_sequence.index = 0;
        }

        vibSampleData.seq_header = (vib_sequence.sensor_ID << SEQ_IND_BITS) | vib_sequence.index;

        //  uncomment if want to see data changes
//        vibSampleData.vib_X++;
//        vibSampleData.vib_Y++;
//        vibSampleData.vib_Z++;

        vibDataBuff[vibIndexWrite] = vibSampleData;

        vibIndexWrite++;


        if(vibIndexWrite >= VIB_BUFF_LEN)
        {
            vibIndexWrite = 0;
        }
    }

    vibTimerISRCount++;

    GPIO_writePin(GPIO_TVIB_TIMER, 0);

    EPWM_clearEventTriggerInterruptFlag(EPWM2_BASE);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP3);
}
#endif  // TEST_COMM

//
// End of File
//
