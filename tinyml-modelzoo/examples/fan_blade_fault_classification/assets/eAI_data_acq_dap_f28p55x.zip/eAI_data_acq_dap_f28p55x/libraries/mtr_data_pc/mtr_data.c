//###########################################################################
// $Copyright:
// Copyright (C) 2017-2024 Texas Instruments Incorporated - http://www.ti.com/
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//   Redistributions of source code must retain the above copyright
//   notice, this list of conditions and the following disclaimer.
//
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the
//   documentation and/or other materials provided with the
//   distribution.
//
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//###########################################################################

//! \file   \libraries\AI_diagnosis\Mtr_data_collection\source\mtr_data.c
//! \brief  Collections of driver functions for machine to machine communication
//! \brief  1. Edge-AI EVM <---> Computer
//! \brief  2. Motor controller <---> Edge-AI EVM
//!

// **************************************************************************
// the includes
#include "mtr_data.h"

// **************************************************************************
// drivers



// **************************************************************************
// modules

// **************************************************************************
// platforms

// **************************************************************************
// the defines

// **************************************************************************
// the globals

// **************************************************************************
// the function prototypes

// Comment out for DA protocol
//#if defined(F28P65X_AI_EVM) || defined(F28P55X_AI_EVM)
//void AI_DATA_setupSCI(void){
//    SCI_resetTxFIFO(SCIA_BASE);
//    SCI_resetRxFIFO(SCIA_BASE);
//    SCI_resetChannels(SCIA_BASE);
////    SCI_setConfig(SCIA_BASE, DEVICE_LSPCLK_FREQ, SCI_BAUD_RATE,
////                 (SCI_CONFIG_WLEN_8 |
////                  SCI_CONFIG_STOP_ONE |
////                  SCI_CONFIG_PAR_EVEN));
//    SCI_setConfig(SCIA_BASE, DEVICE_LSPCLK_FREQ, SCI_BAUD_RATE,
//                 (SCI_CONFIG_WLEN_8 |
//                  SCI_CONFIG_STOP_ONE |
//                  SCI_CONFIG_PAR_NONE));
//
//    SCI_disableInterrupt(SCIA_BASE, SCI_INT_RXFF | SCI_INT_TXFF |
//                         SCI_INT_FE | SCI_INT_OE | SCI_INT_PE |
//                         SCI_INT_RXERR | SCI_INT_RXRDY_BRKDT |
//                         SCI_INT_TXRDY);
//    SCI_enableFIFO(SCIA_BASE);
//    SCI_enableModule(SCIA_BASE);
//}

//#endif


// AI EVM side: SPI receiving motor data
void MTR_DATA_setupSPI_PERI(){

    SPI_disableModule(SPIA_BASE);
    SPI_setConfig(SPIA_BASE, DEVICE_LSPCLK_FREQ, SPI_PROT_POL0PHA0,
                  SPI_MODE_PERIPHERAL, 2000000, 16);
    SPI_setPTESignalPolarity(SPIA_BASE, SPI_PTE_ACTIVE_LOW);
    SPI_enableFIFO(SPIA_BASE);

#if(MTR_DATA_NUM == 4)
    SPI_setFIFOInterruptLevel(SPIA_BASE, SPI_FIFO_TX4, SPI_FIFO_RX4);
#endif
#if(MTR_DATA_NUM == 5)
    SPI_setFIFOInterruptLevel(SPIA_BASE, SPI_FIFO_TX5, SPI_FIFO_RX5);
#endif

    SPI_clearInterruptStatus(SPIA_BASE, SPI_INT_RXFF);
    SPI_enableInterrupt(SPIA_BASE, SPI_INT_RXFF);

    SPI_disableLoopback(SPIA_BASE);
    SPI_setEmulationMode(SPIA_BASE, SPI_EMULATION_FREE_RUN);
    SPI_enableModule(SPIA_BASE);

#if defined(CMD_TO_MTR)
    uint16_t k;
    for(k=0; k<MTR_DATA_NUM; k++){
        SPI_writeDataNonBlocking(SPIA_BASE, 0x0);
    }
#endif
}




// Motor controller side: Sending motor data to Edge AI EVM
#if defined(DATA_TO_AIEVM)
DATA_TOEVM_Handle Data_Obj_init(void *pMemory){

    DATA_TOEVM_Handle handle;
    DATA_TOEVM_Obj *obj;

    // assign the handle
    handle = (DATA_TOEVM_Handle)pMemory;
    obj = (DATA_TOEVM_Obj *)handle;

    obj->spiHandle = SPIB_BASE;

    obj->ADCdataNum = ADC_DATA_NUM_TOEVM;

    return(handle);
}

void MTR_DATA_setupSPI_CTRL(DATA_TOEVM_Handle handle){

    DATA_TOEVM_Obj *obj = (DATA_TOEVM_Obj *)handle;

    SPI_disableModule(obj->spiHandle);

    SPI_setConfig(obj->spiHandle, DEVICE_LSPCLK_FREQ, SPI_PROT_POL0PHA0,
                  SPI_MODE_CONTROLLER, 2000000, 16);

    SPI_disableLoopback(obj->spiHandle);
    SPI_setEmulationMode(obj->spiHandle, SPI_EMULATION_FREE_RUN);
    SPI_enableFIFO(obj->spiHandle);
    SPI_enableModule(obj->spiHandle);
}

void CTRL_writeData(DATA_TOEVM_Handle handle){

    DATA_TOEVM_Obj *obj = (DATA_TOEVM_Obj *)handle;
    uint16_t cnt;

    SPI_resetTxFIFO(obj->spiHandle);

#if defined(RAW_CURRENT)
    for(cnt=0; cnt < (obj->ADCdataNum); cnt++){
        SPI_writeDataNonBlocking(obj->spiHandle, (*obj->ptrData[cnt] & 0xFFFF));
    }
#endif

#if !defined(RAW_CURRENT)
    for(cnt=0; cnt < 3; cnt++){
        SPI_writeDataNonBlocking(obj->spiHandle, (*obj->ptrCurData[cnt] & 0xFFF));
    }
    SPI_writeDataNonBlocking(obj->spiHandle, (*obj->ptrVolDC & 0xFFFF));
#endif

    obj->speed_Hz_conv = (uint16_t)((*obj->ptrSpeed) * obj->speedGain);
    SPI_writeDataNonBlocking(obj->spiHandle, obj->speed_Hz_conv & 0xFFFF);
}

#if defined(CMD_AI_EVM)

HOST_CMD_Handle Host_comm_init(void *pMemory){

    HOST_CMD_Handle handle;
    HOST_CMD_Obj *obj;

    handle = (HOST_CMD_Handle)pMemory;
    obj = (HOST_CMD_Obj*) handle;
    obj->spiHandle = SPIB_BASE;

    return(handle);
}

// background
void refreshHostcmd(HOST_CMD_Handle handle){

    HOST_CMD_Obj *obj = (HOST_CMD_Obj *)handle;

    if(SPI_getRxFIFOStatus(obj->spiHandle) && SPI_readDataNonBlocking(obj->spiHandle) == 0x4353){
        obj->mtr_op_cmd = SPI_readDataNonBlocking(obj->spiHandle) & 0xFF;
        obj->speed_cmd = SPI_readDataNonBlocking(obj->spiHandle)*obj->speed_sf;
    }
    SPI_resetRxFIFO(obj->spiHandle);
}

#endif
#endif


// end of file
