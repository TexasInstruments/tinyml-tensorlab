//###########################################################################
// $Copyright:
// Copyright (C) 2017-2024 Texas Instruments Incorporated - http://www.ti.com/
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//   Redistributions of source code must retain the above copyright
//   notice, this list of conditions and the following disclaimer.
//
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the
//   documentation and/or other materials provided with the
//   distribution.
//
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//###########################################################################

//! \file   \libraries\AI_diagnosis\Mtr_data\include\mtr_data.h
//! \brief  Header file for "mtr_data.c"
//!

#ifndef MTR_DATA_H
#define MTR_DATA_H

//*****************************************************************************
//
// If building with a C++ compiler, make all of the definitions in this header
// have a C binding.
//
//*****************************************************************************
#ifdef __cplusplus
extern "C"
{
#endif

//*****************************************************************************
//
//! \defgroup
//! @{
//
//*****************************************************************************

// the includes
#include <math.h>

//#include "libraries/math/include/math.h"

// drivers
#include <src_device/device.h>
#if defined(DMCPFC_REV3P2)
#include "hal_daq.h"
#else
#include "hal.h"
#endif
//#include "libraries/math/include/math.h"


// the defines


// **************************************************************************
//
//  Data Type
//
// **************************************************************************
#if defined(F28P65X_AI_EVM) || defined(F28P55X_AI_EVM)

#define MTR_DATA_NUM                    5     // Current(3 phase)+DC Voltage+Speed

// TODO: connect to AI data object, priority: low
extern void AI_DATA_setupSCI(void);
extern void MTR_DATA_setupSPI_PERI(void);

#endif

//*****************************************************************************
//
//
//*****************************************************************************
#if defined(DATA_TO_AIEVM)

#define ADC_DATA_NUM_TOEVM                  4        // Current(3-phase)+DC bus voltage

#if defined(RAW_CURRENT)
typedef struct _DATA_TOEVM_Obj_
{
    volatile uint16_t *ptrData[ADC_DATA_NUM_TOEVM];
    volatile float32_t *ptrSpeed;
    uint16_t speed_Hz_conv;
    uint32_t spiHandle;
    uint16_t ADCdataNum;
    float32_t speedGain;                        // gain to convert motor speed in float to int
}DATA_TOEVM_Obj, *DATA_TOEVM_Handle;
#endif

// Analog data is out from ADC PPB
#if !defined(RAW_CURRENT)
typedef struct _DATA_TOEVM_Obj_
{
    volatile uint32_t *ptrCurData[3];
    volatile uint16_t *ptrVolDC;
    volatile float32_t *ptrSpeed;
    uint16_t speed_Hz_conv;
    uint32_t spiHandle;
    uint16_t ADCdataNum;
    float32_t speedGain;                        // gain to convert motor speed in float to int
}DATA_TOEVM_Obj, *DATA_TOEVM_Handle;
#endif

extern DATA_TOEVM_Handle Data_Obj_init(void *pMemory);
extern void MTR_DATA_setupSPI_CTRL(DATA_TOEVM_Handle handle);
extern void CTRL_writeData(DATA_TOEVM_Handle handle);
#endif

#if defined(CMD_AI_EVM)
typedef struct _HOST_CMD_Obj_{
    float32_t speed_cmd;
    float32_t speed_sf;
    uint16_t mtr_op_cmd;
    uint32_t spiHandle;
}HOST_CMD_Obj, *HOST_CMD_Handle;
extern HOST_CMD_Handle Host_comm_init(void *pMemory);
extern void refreshHostcmd();
#endif


//*****************************************************************************
//
// Close the Doxygen group.
//! @}
//
//*****************************************************************************

//*****************************************************************************
//
// Mark the end of the C bindings section for C++ compilers.
//
//*****************************************************************************
#ifdef __cplusplus
}
#endif // extern "C"

#endif // end of MTRDATA_H definition
