//###########################################################################
// $Copyright:
// Copyright (C) 2017-2024 Texas Instruments Incorporated - http://www.ti.com/
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//   Redistributions of source code must retain the above copyright
//   notice, this list of conditions and the following disclaimer.
//
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the
//   documentation and/or other materials provided with the
//   distribution.
//
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//###########################################################################

#ifndef APPLICATION_H_
#define APPLICATION_H_

#include "user_input_config.h"
#include "nn_utils.h"


/*****************************************************************************/
/* Application specific data Structures                                                           */
/*****************************************************************************/


//*****************************************************************************
// Derived Defines
//*****************************************************************************
//#define fft_size        (1 << fft_stages)
//#define fft_offset 10*logf(FRAME_SIZE)         //Commented without check
#if !defined(FE_RAW)
#define FE_FFT_SIZE      (1 << FE_FFT_STAGES)
#else
#define FE_FFT_SIZE        128
//#define FE_FEATURE_SIZE_PER_FRAME         (FE_FFT_SIZE)
#endif

#define NN_WL                          (1)

#if (FE_STACKING_CHANNELS==1)
#define NN_HL                          (FE_STACKING_FRAME_WIDTH)
#elif (FE_STACKING_CHANNELS==3)
#define NN_HL                          (FE_NUM_FRAME_CONCAT*FE_FEATURE_SIZE_PER_FRAME)
#endif

typedef struct
{
    float32_t frame[FE_NUM_FRAME_CONCAT][FE_FEATURE_SIZE_PER_FRAME];
} NN_frameFormat_float_t;

typedef union
{
    float32_t data[FE_STACKING_CHANNELS][NN_WL][NN_HL];
    float32_t data_flatten[FE_STACKING_CHANNELS*NN_WL*NN_HL];
#if defined(FRAME_CONCAT)
    NN_frameFormat_float_t inputCh[FE_STACKING_CHANNELS];
#endif
} NN_input_float_t;

typedef struct
{
    int8_t frame[FE_NUM_FRAME_CONCAT][FE_FEATURE_SIZE_PER_FRAME];
} NN_frameFormat_int8_t;

typedef union
{
    int8_t data[FE_STACKING_CHANNELS][NN_WL][NN_HL];
    int8_t data_flatten[FE_STACKING_CHANNELS*NN_WL*NN_HL];
#if defined(FRAME_CONCAT)
    NN_frameFormat_int8_t inputCh[FE_STACKING_CHANNELS];
#endif
} NN_input_int8_t;

typedef struct
{
    int8_t buf0[FE_NN_OUT_SIZE];

#if defined(NN_DUAL_OUTPUT)
    int8_t buf1[FE_NN_OUT_SIZE];
#endif
} NN_output_int8_t;


typedef struct
{
    NN_class_e class_detected;
    NN_input_int8_t nn_input_int;
    NN_output_int8_t nn_output_int;
    float softmax[FE_NN_OUT_SIZE];
} NN_data_t;

/*****************************************************************************/
/* External variables                                                        */
/*****************************************************************************/

extern NN_data_t nnData;
//NN_data_t nnData;

//extern NN_input_int8_t nn_input_test_int;
extern float model_test_input[];
extern NN_input_float_t nn_input_test;


#endif /* APPLICATION_H_ */
