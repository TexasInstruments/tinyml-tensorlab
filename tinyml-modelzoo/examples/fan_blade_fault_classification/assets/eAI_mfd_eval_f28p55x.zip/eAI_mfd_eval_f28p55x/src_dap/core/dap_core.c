//###########################################################################
// $Copyright:
// Copyright (C) 2017-2024 Texas Instruments Incorporated - http://www.ti.com/
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//   Redistributions of source code must retain the above copyright
//   notice, this list of conditions and the following disclaimer.
//
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the
//   documentation and/or other materials provided with the
//   distribution.
//
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//###########################################################################
//
// FILE:   dap_core.c
//
//!
//! This contains definition of core API functions required to support device
//! agent protocol(dap)
//


#include "dap_core.h"
#include "string.h"

//external variables
int rx_fifo_level_reconfig;
int first_sensor_index;
int second_sensor_index;
int third_sensor_index;
int forth_sensor_index;
int index_of_property;
volatile int start_sending_data = 0;
volatile int payload_length_byte_size = 0;

extern const char Device_name[];
extern volatile uint16_t property_val_uint16;
extern volatile uint32_t property_val_uint32;

volatile uint16_t test_property_uint16 = 0;
volatile uint32_t test_property_uint32 = 0;


/*Initialization Functions*/
void SCI_init(){
    /********* SCI Initialization **********/

    //Register SCI RX Interrupt
    Interrupt_register(INT_SCIA_RX, &sciRxISR);
    //
    // Initialize SCIA and its FIFO.
    //
    SCI_performSoftwareReset(SCI_INST_BASE_ADDR);

    //
    // Configure SCIA for echoback.
    //
    SCI_setConfig(SCI_INST_BASE_ADDR, DEVICE_LSPCLK_FREQ, SCI_BAUD_RATE, (SCI_CONFIG_WLEN_8 |
                                                        SCI_CONFIG_STOP_ONE |
                                                        SCI_CONFIG_PAR_NONE));

    SCI_setFIFOInterruptLevel(SCI_INST_BASE_ADDR, TX_FIFO_LEVEL, RX_FIFO_LEVEL);
    //SCI_setFIFOInterruptLevel(SCIA_BASE, TX_FIFO_LEVEL, RX_FIFO_LEVEL);
    SCI_resetChannels(SCI_INST_BASE_ADDR);
    SCI_resetRxFIFO(SCI_INST_BASE_ADDR);
    SCI_resetTxFIFO(SCI_INST_BASE_ADDR);
    SCI_clearInterruptStatus(SCI_INST_BASE_ADDR, SCI_INT_RXFF);
    SCI_enableFIFO(SCI_INST_BASE_ADDR);
    SCI_enableModule(SCI_INST_BASE_ADDR);

    rx_fifo_level_reconfig = 4;
    //
    // RX and TX FIFO Interrupts Enabled
    //
    SCI_enableInterrupt(SCI_INST_BASE_ADDR, (SCI_INT_RXFF));
    SCI_disableInterrupt(SCI_INST_BASE_ADDR, SCI_INT_RXERR);

    SCI_performSoftwareReset(SCI_INST_BASE_ADDR);

    Interrupt_enable(INT_SCIA_RX);

    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP9);
}

/* Top Level Functions */
void guiInitialization(){
    SCI_init();
}

void get_capabilites_response()
{
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, START_BYTE);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, get_capabilities);
    int get_capability_payload_length = strlen(Device_name)+4;
    uint32_t payload_length = payload_length_cal(get_capability_payload_length);
    //SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, get_capability_length);
    if(payload_length_byte_size==1)
    {
        uint8_t data_byte1 = payload_length & 0xFF;
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte1);
    }
    else if(payload_length_byte_size==2)
    {
        uint8_t data_byte1 = (payload_length>>8) & 0xFF;
        uint8_t data_byte2 = payload_length & 0xFF;
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte1);
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte2);
    }
    else if(payload_length_byte_size==3)
    {
        uint8_t data_byte1 = (payload_length>>16) & 0xFF;
        uint8_t data_byte2 = (payload_length>>8) & 0xFF;
        uint8_t data_byte3 = payload_length & 0xFF;
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte1);
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte2);
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte3);
    }
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, API_version);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, capability_bits_flag);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, sdk_major_version);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, sdk_minor_version);
    SCI_writeCharArray(SCI_INST_BASE_ADDR, (uint16_t*)Device_name, strlen(Device_name));
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, END_BYTE);
}

void list_sensor_response(uint16_t sensor_count, uint16_t sensor_index, const char sensor_index_info[])
{
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, START_BYTE);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, list_sensors);
    int sensor_info_length = (strlen(sensor_index_info))+2;
    uint32_t payload_length = payload_length_cal(sensor_info_length);
    //SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, sensor_info_length);
    if(payload_length_byte_size==1)
    {
        uint8_t data_byte1 = payload_length & 0xFF;
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte1);
    }
    else if(payload_length_byte_size==2)
    {
        uint8_t data_byte1 = (payload_length>>8) & 0xFF;
        uint8_t data_byte2 = payload_length & 0xFF;
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte1);
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte2);
    }
    else if(payload_length_byte_size==3)
    {
        uint8_t data_byte1 = (payload_length>>16) & 0xFF;
        uint8_t data_byte2 = (payload_length>>8) & 0xFF;
        uint8_t data_byte3 = payload_length & 0xFF;
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte1);
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte2);
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte3);
    }
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, sensor_count);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, sensor_index);
    SCI_writeCharArray(SCI_INST_BASE_ADDR, (uint16_t*)sensor_index_info, sensor_info_length-2);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, END_BYTE);
}

void list_model_response(uint16_t model_count, uint16_t model_index, const char model_index_info[])
{
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, START_BYTE);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, list_models);
    int model_info_length = (strlen(model_index_info))+2;
    uint32_t payload_length = payload_length_cal(model_info_length);
    //SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, model_info_length);
    if(payload_length_byte_size==1)
    {
        uint8_t data_byte1 = payload_length & 0xFF;
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte1);
    }
    else if(payload_length_byte_size==2)
    {
        uint8_t data_byte1 = (payload_length>>8) & 0xFF;
        uint8_t data_byte2 = payload_length & 0xFF;
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte1);
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte2);
    }
    else if(payload_length_byte_size==3)
    {
        uint8_t data_byte1 = (payload_length>>16) & 0xFF;
        uint8_t data_byte2 = (payload_length>>8) & 0xFF;
        uint8_t data_byte3 = payload_length & 0xFF;
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte1);
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte2);
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte3);
    }
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, model_count);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, model_index);
    SCI_writeCharArray(SCI_INST_BASE_ADDR, (uint16_t*)model_index_info, (model_info_length-2));
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, END_BYTE);
}


void configure_pipeline_response()
{
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, START_BYTE);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, configure_pipeline);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, configure_pipeline_length);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, END_BYTE);
}


void start_streaming_response()
{
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, START_BYTE);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, start_streaming);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, start_streaming_length);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, END_BYTE);

    start_sending_data = 1;
}

int payload_length_cal(uint32_t original_data_length)
{
    uint32_t modified_data_length;
    if(original_data_length<=0x7f)
    {
        modified_data_length = original_data_length;
        payload_length_byte_size = 1;
    }
    else if((original_data_length>=0x80) && (original_data_length<=0x3ff))
    {
        modified_data_length = 0x8000 + original_data_length;
        payload_length_byte_size = 2;
    }
    else if(original_data_length>=0x4000)
    {
        modified_data_length = 0xc00000 + original_data_length;
        payload_length_byte_size = 3;
    }
    return modified_data_length;
}

void received_data_response(uint32_t data_payload_length, uint16_t channel_value, uint16_t* data_array)
{
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, START_BYTE);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, (0x10 | channel_value));
    uint32_t payload_length = payload_length_cal(data_payload_length);
    if(payload_length_byte_size==1)
    {
        uint8_t data_byte1 = payload_length & 0xFF;
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte1);
    }
    else if(payload_length_byte_size==2)
    {
        uint8_t data_byte1 = (payload_length>>8) & 0xFF;
        uint8_t data_byte2 = payload_length & 0xFF;
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte1);
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte2);
    }
    else if(payload_length_byte_size==3)
    {
        uint8_t data_byte1 = (payload_length>>16) & 0xFF;
        uint8_t data_byte2 = (payload_length>>8) & 0xFF;
        uint8_t data_byte3 = payload_length & 0xFF;
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte1);
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte2);
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte3);
    }
    SCI_writeCharArray(SCI_INST_BASE_ADDR, data_array, (data_payload_length));
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, END_BYTE);
}

void stop_streaming_response()
{
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, START_BYTE);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, stop_streaming);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, stop_streaming_length);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, END_BYTE);

    start_sending_data = 0;
}

void property_read_response_uint16(uint16_t property_index, uint16_t property_value)
{
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, START_BYTE);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, property_read);
    //SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, property_read_length);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, 3);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, property_index);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, (property_value>>8) & 0xFF);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, property_value & 0xFF);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, END_BYTE);
}

void property_read_response_uint32(uint16_t property_index, uint32_t property_value)
{
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, START_BYTE);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, property_read);
    //SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, property_read_length);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, 5);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, property_index);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, (property_value>>24) & 0xFF);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, (property_value>>16) & 0xFF);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, (property_value>>8) & 0xFF);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, property_value & 0xFF);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, END_BYTE);
}

void property_written_response(uint16_t property_index)
{
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, START_BYTE);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, property_written);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, property_written_length);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, property_index);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, END_BYTE);
}

void list_property_response(uint16_t property_count, uint16_t property_index, uint16_t property_dataformat, const char property_index_info[])
{
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, START_BYTE);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, list_properties);
    int property_info_length = (strlen(property_index_info))+3;
    uint32_t payload_length = payload_length_cal(property_info_length);
    //SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, property_info_length);
    if(payload_length_byte_size==1)
    {
        uint8_t data_byte1 = payload_length & 0xFF;
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte1);
    }
    else if(payload_length_byte_size==2)
    {
        uint8_t data_byte1 = (payload_length>>8) & 0xFF;
        uint8_t data_byte2 = payload_length & 0xFF;
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte1);
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte2);
    }
    else if(payload_length_byte_size==3)
    {
        uint8_t data_byte1 = (payload_length>>16) & 0xFF;
        uint8_t data_byte2 = (payload_length>>8) & 0xFF;
        uint8_t data_byte3 = payload_length & 0xFF;
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte1);
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte2);
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte3);
    }
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, property_count);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, property_index);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, property_dataformat);
    SCI_writeCharArray(SCI_INST_BASE_ADDR, (uint16_t*)property_index_info, (property_info_length-3));
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, END_BYTE);
}

void list_inference_values_response(uint16_t inference_count, uint16_t inference_index, uint16_t inference_dataformat, const char inference_index_info[])
{
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, START_BYTE);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, list_inferencing_values);
    int inference_info_length = (strlen(inference_index_info))+3;
    uint32_t payload_length = payload_length_cal(inference_info_length);
    //SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, inference_info_length);
    if(payload_length_byte_size==1)
    {
        uint8_t data_byte1 = payload_length & 0xFF;
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte1);
    }
    else if(payload_length_byte_size==2)
    {
        uint8_t data_byte1 = (payload_length>>8) & 0xFF;
        uint8_t data_byte2 = payload_length & 0xFF;
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte1);
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte2);
    }
    else if(payload_length_byte_size==3)
    {
        uint8_t data_byte1 = (payload_length>>16) & 0xFF;
        uint8_t data_byte2 = (payload_length>>8) & 0xFF;
        uint8_t data_byte3 = payload_length & 0xFF;
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte1);
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte2);
        SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, data_byte3);
    }
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, inference_count);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, inference_index);
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, inference_dataformat);
    SCI_writeCharArray(SCI_INST_BASE_ADDR, (uint16_t*)inference_index_info, (inference_info_length-3));
    SCI_writeCharBlockingNonFIFO(SCI_INST_BASE_ADDR, END_BYTE);
}

void data_conversion_from_16_to_8_bits(uint16_t* input_buf, int input_buf_size, uint8_t* output_buf)
{
    int i = 0;

    for(i=0;i<input_buf_size;i++)
    {
        uint8_t byte1 = (input_buf[i]>>8) & 0xFF;
        uint8_t byte2 = input_buf[i] & 0xFF;
        output_buf[i*2] =  byte1 ;
        output_buf[i*2+1] =  byte2;

        //input_buf[i] = ((byte1 << 8) | byte2)   --> In Big_endian format
    }
}


void data_conversion_from_32_to_8_bits(uint32_t* input_buf, int input_buf_size, uint8_t* output_buf)
{
    int i = 0;

    for(i=0;i<input_buf_size;i++)
    {
        uint8_t byte1 = (input_buf[i]>>24) & 0xFF;
        uint8_t byte2 = (input_buf[i]>>16) & 0xFF;
        uint8_t byte3 = (input_buf[i]>>8) & 0xFF;
        uint8_t byte4 = input_buf[i] & 0xFF;
        output_buf[i*4] =  byte1 ;
        output_buf[i*4+1] =  byte2;
        output_buf[i*4+2] =  byte3;
        output_buf[i*4+3] =  byte4;

        //input_buf[i] = ((byte1 << 24) | (byte2 << 16) | (byte3 << 8) | byte4)   --> In Big_endian format
    }
}

/* Interrupt Service Routines */
//
// sciaRXFIFOISR - SCIA Receive FIFO ISR
//
volatile uint16_t temp = 0;
uint16_t rxTempBuffer[16] = {};
uint16_t cmd_ready = 0;
uint16_t cmd_inWait = 0;
uint16_t payload_len = 0;

/*  Preliminary implementation  */
__interrupt void sciRxISR(void)
{

    uint16_t rx_index;

    if((cmd_ready == 0) & (cmd_inWait == 0)){
        // new command comes
        SCI_readCharArray(SCI_INST_BASE_ADDR, rxTempBuffer, 4);

        if(rxTempBuffer[2] == 0x00){
            cmd_ready = 1;
        }

        else{
            // Command is longer than 4-byte
            payload_len = rxTempBuffer[2];
            // Re-configure RXINT level to payload length, assume command length won't exceed 20 byte for now
            SCI_setFIFOInterruptLevel(SCI_INST_BASE_ADDR, TX_FIFO_LEVEL, payload_len);
            SCI_enableInterrupt(SCI_INST_BASE_ADDR, SCI_INT_RXFF);
            cmd_inWait = 1;
        }

    }

    else if((cmd_ready == 0) && (cmd_inWait == 1)){
        for(rx_index=0; rx_index<payload_len; rx_index++){
            rxTempBuffer[4+rx_index] = SCI_readCharNonBlocking(SCI_INST_BASE_ADDR);
        }
        cmd_inWait = 0;
        cmd_ready = 1;
    }


    if(cmd_ready == 1){
        cmd_ready = 0;
        // decode command and respond

        if((rxTempBuffer[0] == START_BYTE) && (rxTempBuffer[4+payload_len-1] == END_BYTE)){
        switch(rxTempBuffer[1]){
             case (get_capabilities_cmd):
                 get_capabilites_response();
                 break;
             case (list_sensors_cmd):
                 list_all_sensors();
                 break;
             case (list_models_cmd):
                 list_all_models();
                 break;
             case (start_streaming_cmd):
                 start_streaming_response();
                 break;
             case (stop_streaming_cmd):
                 stop_streaming_response();
                 break;
             case (list_properties_cmd):
                 list_all_properties();
                 break;
             case (list_inferencing_values_cmd):
                 list_all_inferences();
                 break;

             case (configure_pipeline_cmd):
                     if(rxTempBuffer[3] == Data_Acquisition){
                         // sensor sequence record

                         configure_pipeline_response();

                     }
                     if(rxTempBuffer[3] == Sensor_Inferencing){

                         configure_pipeline_response();
                     }
                     if(rxTempBuffer[3] == Host_Inferencing){
                         if((rxTempBuffer[4]==model_index1) || (rxTempBuffer[4]==model_index2) || (rxTempBuffer[4]==model_index3)){
                             configure_pipeline_response();
                         }
                     }

                  break;
             case (read_property_cmd):

                  index_of_property = rxTempBuffer[3];
                  // Current property is only number of samples which is uint32
                  property_read_response_uint32(index_of_property, property_val_uint32);
                  break;
             case(write_property_cmd):
                  if(rxTempBuffer[2]==5){
                      uint16_t write_ind = rxTempBuffer[3];

                      uint32_t byte1 = rxTempBuffer[4];
                      uint32_t byte2 = rxTempBuffer[5];
                      uint32_t byte3 = rxTempBuffer[6];
                      uint32_t byte4 = rxTempBuffer[7];
                      uint32_t property_value = ((byte1 << 24) | (byte2 << 16) | (byte3 << 8) | byte4);

                      property_val_uint32 = property_value;
                      property_written_response(index_of_property);
                  }
                  break;
        }
        }

        // reset receiving buffer for next command
        memset(rxTempBuffer, 0, sizeof(rxTempBuffer));
        payload_len = 0;
    }



    SCI_enableInterrupt(SCI_INST_BASE_ADDR, RX_FIFO_LEVEL);

    SCI_clearOverflowStatus(SCI_INST_BASE_ADDR);
    SCI_clearInterruptStatus(SCI_INST_BASE_ADDR, SCI_INT_RXFF);

    Interrupt_clearACKGroup(SCI_RX_ACK);
}




